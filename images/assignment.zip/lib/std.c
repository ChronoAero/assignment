#include "std.h"

int print_err(const char* str){
        printf(str);
        exit(-1);
        return -1;
    }