#ifndef LIB_H
#define LIB_H

    #include <stdlib.h>
    #include <stdio.h>

    #define new(T) malloc(sizeof(T))
    #define new_arr(T, x) calloc(x, sizeof(T))

    int print_err(const char* str);

#endif