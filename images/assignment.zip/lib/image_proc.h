#ifndef IMAGE_PROC_H
#define IMAGE_PROC_H

    #include "matrix.h"
    #include "color.h"
    #include <stdbool.h>
    #include "std.h"
    #include "string.h"
    #include "linalg.h"

    #ifndef MATRIX_COLOR
    #define MATRIX_COLOR
        define_matrix(Color);
    #endif

    #ifndef MATRIX_INT
    #define MATRIX_INT
        define_matrix(int);
    #endif

    //TASK 2.1
    //Uncomment the following when you start working on task 2.1
    //#define TODO_IMAGE_PROCESS_COLOR_POINT

    #ifdef TODO_IMAGE_PROCESS_COLOR_POINT
        void image_proc_process_color_point(Matrix(Color)* source,  Matrix(int)* result, <complete-this>);
    #endif

    void image_proc_get_grayscale(Matrix(Color)* source, Matrix(int)* result);
    void image_proc_light_dark(Matrix(int)* mat, int threshold);    
    void image_proc_opening_filter(Matrix(int)* mat);
    int image_proc_coords_accumulate(Matrix(int) mat, int (*f) (int, int));
    
    typedef struct LineData{
        double a;
        double b;
    } LineData;

    LineData image_proc_linreg(Matrix(int) mat);

    void image_proc_draw_line(Matrix(int)* mat, LineData ld);

    typedef struct PolyData{
        double a0;
        double a1;
        double a2;
        double a3;
    } PolyData;

    PolyData image_proc_polyreg(Matrix(int) mat);

     void image_proc_draw_poly(Matrix(int)* mat, PolyData pd);

#endif