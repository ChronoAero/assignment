#include "linalg.h"

void matrix_linalg_row_scale(Matrix(double)* mat, int row_num, double scale){
    for(int i=0; i<mat->cols; i++){
        _xsub(*mat, row_num, i) *= scale;
        if(_xsub(*mat, row_num, i) == -0.0){
            _xsub(*mat, row_num, i) = 0;
        }
    }
}

void matrix_linalg_row_op(Matrix(double)* mat, int row_num_applied, int row_num_from, double scale_from){
    for(int i=0; i<mat->cols; i++){
        _xsub(*mat, row_num_applied, i) += scale_from * _sub(*mat, row_num_from, i);
        if(_xsub(*mat, row_num_applied, i) == -0.0){
            _xsub(*mat, row_num_applied, i) = 0;
        }
    }
}

void matrix_linalg_rref(Matrix(double)* mat){ 
    for(int i=0; i<(mat->rows<mat->cols? mat->rows : mat->cols); i++){
        matrix_linalg_row_scale(mat, i, 1.0/_sub(*mat, i, i));
        for(int j=i+1; j<mat->rows; j++){
            matrix_linalg_row_op(mat, j, i, -_sub(*mat, j, i));
        }
    }
    for(int i=0; i<(mat->rows<mat->cols? mat->rows : mat->cols); i++){
        for(int j=0; j<i; j++){
            matrix_linalg_row_op(mat, j, i, -_sub(*mat, j, i));
        }
    }
}

//only on invertible matrix for now

void matrix_linalg_get_id(Matrix(double)* mat){
    if(mat->cols != mat->rows){print_err("Error: The given matrix is not a square matrix");}
    for(int i=0; i<mat->rows; i++){
        for(int j=0; j<mat->cols; j++){
            _xsub(*mat, i, j) = (i==j)? 1 : 0;
        }
    }
}

void matrix_linalg_get_inv(Matrix(double)* mat){
    matrix_copy(double, AT, *mat);
    matrix_op_self(AT, T*);
    matrix_copy(double, I, *mat);
    matrix_linalg_get_id(&I);
    matrix_all(double, inv_calculator, mat->cols*2, mat->cols, 0);
    matrix_op_matrix(inv_calculator, AT, *s*, I);
    matrix_op_self(inv_calculator, T*);
    matrix_linalg_rref(&inv_calculator);

    matrix_from_slice(double, res, inv_calculator,  0, mat->cols, mat->cols, mat->cols*2);

    matrix_free(AT);
    matrix_free(I);
    matrix_free(inv_calculator);

    free(mat->array);
    mat->array = res.array;
}