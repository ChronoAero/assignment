#ifndef MATRIX_H
#define MATRIX_H

#include <stdio.h>
#include "std.h"

#define define_matrix(T) typedef struct __##T##_matrix { \
   int rows; \
   int cols; \
   T* array; \
   T* temp; \
} __##T##_matrix

#define Matrix(T) __##T##_matrix
#define matrix_from_array2D(__type, __M, __A) Matrix(__type) __M; __M.rows = sizeof(__A)/sizeof(__A[0]);\
   __M.cols = sizeof(__A[0])/sizeof(__A[0][0]);\
   __M.array = new_arr(__type, __M.cols*__M.rows);\
   for(int i=0; i<sizeof(__A)/sizeof(__A[0]); i++){ \
      for(int j=0; j<sizeof(__A[0])/sizeof(__A[0][0]); j++){ \
         __M.array[i*__M.cols + j] = __A[i][j];\
      }\
   }\

#define matrix_print(__M, __printer_func) \
   printf("[\n"); \
   for(int i=0; i<__M.rows; i++){ \
      printf("  ["); \
      for(int j=0; j<__M.cols; j++){ \
         __printer_func(__M.array[i*__M.cols + j]); \
      }\
      printf("]\n"); \
   } \
   printf("]\n");

#define _sub(__M, _i, _j) (((_j) < (__M).cols && (_j) >=0) ? (((_i)<(__M).rows && (_i) >= 0) ? (__M).array[(_i) * (__M).cols + (_j)] : print_err("Error: First index, i, is out of bound!\n")) : print_err("Error: Second index, j, is out of bound!\n"))
#define _xsub(__M, _i, _j) (__M).array[(_i) * (__M).cols + (_j)]
#define matrix_check_not_overflow(__M, _i, _j) ((_j) < (__M).cols && (_j) >= 0 && (_i) < (__M).rows && (_i) >= 0)

#define matrix_free(__M) free((__M).array)

#define matrix_from_matrix(__type, __M1, __M2) Matrix(__type) (__M1); (__M1).rows = (__M2).rows;\
   (__M1).cols = (__M2).cols;\
   (__M1).array = new_arr(__type, (__M2).cols*(__M2).rows);\
   for(int i=0; i<(__M2).rows; i++){ \
      for(int j=0; j<(__M2).cols; j++){ \
         (__M1).array[i*(__M1).cols + j] = _sub((__M2), i, j);\
      }\
   }\

#define matrix_copy(__type, __M1, __M2) matrix_from_matrix(__type, __M1, __M2)

//TASK 1.1
#define matrix_all(__type, __M, __rows, __cols, __value) Matrix(__type) __M; \
   "<complete_the_definition_here>"


//TASK 1.2 
#define matrix_op_matrix(__M0, __M1, __op, __M2) if((#__op)[0] == '*' && (#__op)[1] == 'x' && (#__op)[2] == '*'){\
      if(!(__M1.cols == __M2.rows)){print_err("operator*x* -- Error: The matrix multiplication M1 x M2 is not defined");}\
      if(!(__M0.rows == __M1.rows && __M0.cols == __M2.cols)){print_err("operator*x* -- Error: Wrong M0 size");}\
         "<complete_the_definition_here>"; \
   }else if((#__op)[0] == '*' && (#__op)[1] == 's' && (#__op)[2] == '*'){\
      if(!(__M1.cols == __M2.cols)) {print_err("operator*s* -- Error: M1 and M2 does not have the same amount of columns");}\
      if(!(__M0.rows == (__M1.rows + __M2.rows) && __M0.cols == __M1.cols)) {print_err("operator*s* -- Error: Wrong M0 size");}\
      for(int i=0; i<__M1.rows; i++){ \
         for(int j=0; j<__M1.cols; j++){ \
            _xsub(__M0, i, j) = _xsub(__M1, i, j); \
         } \
      }  \
      for(int i=__M1.rows; i<__M1.rows+__M2.rows; i++){ \
         for(int j=0; j<__M2.cols; j++){ \
            _xsub(__M0, i, j) = _xsub(__M2, i-__M1.rows, j); \
         } \
      }  \
      \
   }else{\
      int x = 0;\
      int s = 0;\
      if(!(__M1.cols == __M2.cols && __M1.rows == __M2.rows)) {print_err("matrix_op -- Error: M1 and M2 does not have the same size");}\
      if(!(__M0.cols == __M2.cols && __M0.rows == __M2.rows)) {print_err("matrix_op -- Error: Wrong M0 size");}\
      for(int i=0; i<__M1.rows; i++){ \
         for(int j=0; j<__M1.cols; j++){ \
            _xsub(__M0, i, j) = _sub(__M1, i, j)  __op _sub(__M2, i, j); \
         } \
      }  \
   }

#define matrix_op_self(__M, __func) if((#__func)[0] == 'T' && (#__func)[1] == '*'){\
      for(int i=0; i<__M.rows; i++){ \
         __M.temp = new_arr(__M.array[0], __M.rows * __M.cols); \
         for(int i=0; i<__M.rows; i++){ \
            for(int j=0; j<__M.cols; j++){ \
               __M.temp[j * __M.rows + i] = __M.array[i * __M.cols + j]; \
            } \
         } \
         int tmp = __M.cols; \
         __M.cols = __M.rows; \
         __M.rows = tmp; \
         free(__M.array); \
         __M.array = __M.temp; \
      } \
   }else{\
      for(int i=0; i<__M.rows; i++){ \
         for(int j=0; j<__M.cols; j++){ \
            int T = 0; \
            _xsub(__M, i, j) = __func(_sub(__M, i, j)); \
         } \
      } \
   }

//TASK 1.3
#define matrix_from_slice(__type, __M1, __M2, start_row, end_row, start_col, end_col) Matrix(__type) (__M1); \
   "<complete_the_definition_here>"

//TASK 1.4
#define matrix_reshape(__M, _new_rows, _new_cols) if(__M.rows*__M.cols != _new_cols * _new_rows){printf("matrix_reshape -- Error: Cannot resize a matrix with size %dx%d to %dx%d", __M.rows, __M.cols, _new_rows, _new_cols); exit(-1);} \
   "<complete_the_definition_here>"


#endif