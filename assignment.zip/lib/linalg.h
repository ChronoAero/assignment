#ifndef LINALG_H
#define LINALG_H

    #include "matrix.h"
    #include <math.h>

    #ifndef MATRIX_DOUBLE
    #define MATRIX_DOUBLE
        define_matrix(double);
    #endif

    void matrix_linalg_row_scale(Matrix(double)* mat, int row_num, double scale);
    void matrix_linalg_row_op(Matrix(double)* mat, int row_num_applied, int row_num_from, double scale_from);
    void matrix_linalg_rref(Matrix(double)* mat);
    void matrix_linalg_get_id(Matrix(double)* mat);
    void matrix_linalg_get_inv(Matrix(double)* mat);

#endif