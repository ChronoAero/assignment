#ifndef COLOR_H
#define COLOR_H

#include <stdio.h>

typedef struct Color{
    int R;
    int G;
    int B;
} Color;

#endif